import sys
import socket
import os
import logging
import configparser
import threading
import webbrowser
import atexit
from flask import Flask, render_template, request
from flask_socketio import SocketIO
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QTextEdit, 
    QTabWidget, QPushButton, QLineEdit, QLabel, QCheckBox, QFormLayout, QMessageBox
)
from PyQt5.QtCore import Qt, pyqtSignal, QObject

class ServerSignals(QObject):
    log_signal = pyqtSignal(str)
    status_signal = pyqtSignal(bool)

class FlaskServerGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.server_thread = None
        self.signals = ServerSignals()
        self.init_ui()
        self.load_settings()
        self.setup_logging()

    def init_ui(self):
        self.setWindowTitle('Violence Local Server Manager')
        self.setGeometry(100, 100, 800, 600)

        main_widget = QWidget()
        layout = QVBoxLayout()

        # Server Controls
        self.btn_toggle = QPushButton('Start Server')
        self.btn_toggle.clicked.connect(self.toggle_server)
        self.status_label = QLabel('Status: Stopped')

        # Log Display
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)

        # Settings Tab
        settings_tab = QWidget()
        settings_layout = QFormLayout()

        self.host_input = QLineEdit('0.0.0.0')
        self.port_input = QLineEdit('5000')
        self.browser_check = QCheckBox('Open browser automatically')
        self.browser_check.setChecked(True)
        self.debug_check = QCheckBox('Enable debug mode')
        self.debug_check.setChecked(True)
        self.templates_path = QLineEdit(os.path.abspath('templates'))
        self.static_path = QLineEdit(os.path.abspath('static'))

        settings_layout.addRow('Host:', self.host_input)
        settings_layout.addRow('Port:', self.port_input)
        settings_layout.addRow(self.browser_check)
        settings_layout.addRow(self.debug_check)
        settings_layout.addRow('Templates Path:', self.templates_path)
        settings_layout.addRow('Static Path:', self.static_path)
        settings_tab.setLayout(settings_layout)

        # Tabs
        tabs = QTabWidget()
        tabs.addTab(settings_tab, "Settings")

        layout.addWidget(self.status_label)
        layout.addWidget(self.btn_toggle)
        layout.addWidget(tabs)
        layout.addWidget(QLabel('Server Logs:'))
        layout.addWidget(self.log_display)

        main_widget.setLayout(layout)
        self.setCentralWidget(main_widget)

        self.signals.log_signal.connect(self.update_log)
        self.signals.status_signal.connect(self.update_status)

    def setup_logging(self):
        class GUILogHandler(logging.Handler):
            def __init__(self, signals):
                super().__init__()
                self.signals = signals

            def emit(self, record):
                msg = self.format(record)
                self.signals.log_signal.emit(msg)

        logger = logging.getLogger()
        logger.addHandler(GUILogHandler(self.signals))
        logger.setLevel(logging.DEBUG)

    def load_settings(self):
        self.config = configparser.ConfigParser()
        if os.path.exists('storage.cfg'):
            self.config.read('storage.cfg')
        
        self.host_input.setText(self.config.get('Server', 'host', fallback='0.0.0.0'))
        self.port_input.setText(self.config.get('Server', 'port', fallback='5000'))
        self.browser_check.setChecked(self.config.getboolean('Server', 'auto_open', fallback=True))
        self.debug_check.setChecked(self.config.getboolean('Server', 'debug', fallback=True))
        self.templates_path.setText(self.config.get('Paths', 'templates', fallback=os.path.abspath('templates')))
        self.static_path.setText(self.config.get('Paths', 'static', fallback=os.path.abspath('static')))

    def save_settings(self):
        self.config = configparser.ConfigParser()
        self.config['Server'] = {
            'host': self.host_input.text(),
            'port': self.port_input.text(),
            'auto_open': str(self.browser_check.isChecked()),
            'debug': str(self.debug_check.isChecked())
        }
        self.config['Paths'] = {
            'templates': self.templates_path.text(),
            'static': self.static_path.text()
        }
        with open('storage.cfg', 'w') as configfile:
            self.config.write(configfile)

    def update_log(self, message):
        self.log_display.append(message)
        
    def update_status(self, running):
        self.status_label.setText(f'Status: {"Running" if running else "Stopped"}')
        self.btn_toggle.setText('Stop Server' if running else 'Start Server')

    def toggle_server(self):
        if self.server_thread and self.server_thread.is_alive():
            self.stop_server()
        else:
            self.start_server()

    def start_server(self):
        try:
            self.save_settings()
            self.server_thread = ServerThread(
                host=self.host_input.text(),
                port=int(self.port_input.text()),
                debug=self.debug_check.isChecked(),
                templates_path=self.templates_path.text(),
                static_path=self.static_path.text(),
                auto_open_browser=self.browser_check.isChecked(),
                signals=self.signals
            )
            self.server_thread.start()
            self.signals.status_signal.emit(True)
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))

    def stop_server(self):
        if self.server_thread:
            self.server_thread.shutdown()
            self.server_thread.join(2)
            self.server_thread = None
            self.signals.status_signal.emit(False)
            logging.info("Server stopped")

    def closeEvent(self, event):
        self.stop_server()
        event.accept()

class ServerThread(threading.Thread):
    def __init__(self, host, port, debug, templates_path, static_path, auto_open_browser, signals):
        super().__init__()
        self.host = host
        self.port = port
        self.debug = debug
        self.templates_path = templates_path
        self.static_path = static_path
        self.auto_open_browser = auto_open_browser
        self.signals = signals
        self.observer = None
        self.socketio = None
        self.app = None
        self._stop_event = threading.Event()

    def run(self):
        try:
            self.app = Flask(__name__)
            self.app.template_folder = self.templates_path
            self.app.static_folder = self.static_path
            self.socketio = SocketIO(self.app, async_mode='threading')

            self.setup_routes()
            self.setup_watcher()

            if self.auto_open_browser and os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
                threading.Thread(target=self.open_browser).start()

            self.socketio.run(
                self.app,
                host=self.host,
                port=self.port,
                debug=self.debug,
                use_reloader=False,
                log_output=True,
                allow_unsafe_werkzeug=True
            )

        except Exception as e:
            logging.error(f"Server error: {str(e)}")

    def setup_routes(self):
        @self.app.route('/')
        def index():
            logging.debug('Handling request for /')
            return render_template('index.html')

        @self.socketio.on('connect')
        def handle_connect():
            try:
                client_ip = request.remote_addr
                logging.info(f'New connection from {client_ip}')
            except RuntimeError:
                pass

    def setup_watcher(self):
        class ReloadHandler(FileSystemEventHandler):
            def __init__(self, socketio):
                super().__init__()
                self.socketio = socketio

            def on_modified(self, event):
                if not event.is_directory:
                    if 'templates' in event.src_path or 'static' in event.src_path:
                        logging.info(f"Detected change in {event.src_path}, reloading clients...")
                        self.socketio.emit('reload')

        try:
            if all(os.path.isdir(p) for p in [self.templates_path, self.static_path]):
                self.observer = Observer()
                event_handler = ReloadHandler(self.socketio)
                self.observer.schedule(event_handler, self.templates_path, recursive=True)
                self.observer.schedule(event_handler, self.static_path, recursive=True)
                self.observer.start()
                logging.info("File watcher started")
                atexit.register(self.shutdown_observer)
        except Exception as e:
            logging.error(f"File watcher error: {str(e)}")

    def shutdown_observer(self):
        if self.observer and self.observer.is_alive():
            self.observer.stop()
            self.observer.join()
            logging.info("File watcher stopped")

    def open_browser(self):
        webbrowser.open(f'http://{socket.gethostbyname(socket.gethostname())}:{self.port}')

    def shutdown(self):
        try:
            if self.socketio:
                self.socketio.stop()
            if self.observer:
                self.shutdown_observer()
            if self.app and hasattr(self.app, 'werkzeug_server'):
                self.app.werkzeug_server.shutdown()
            self._stop_event.set()
            logging.info("Server shutdown initiated")
        except Exception as e:
            logging.error(f"Error during shutdown: {str(e)}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = FlaskServerGUI()
    window.show()
    sys.exit(app.exec_())