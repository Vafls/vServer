import socket
from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    print('Client connected')

if __name__ == '__main__':
    import threading

    def open_browser():
        import webbrowser
        ip_address = socket.gethostbyname(socket.gethostname())
        webbrowser.open(f'http://{ip_address}:5000')

    threading.Thread(target=open_browser).start()

    socketio.run(app, host='0.0.0.0', port=5000)
